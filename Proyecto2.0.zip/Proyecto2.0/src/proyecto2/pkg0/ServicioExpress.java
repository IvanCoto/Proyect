
package proyecto2.pkg0;

public class ServicioExpress {
    
    String nombrecliente;
    int numFactura;
    int costoEnvio;
    int subtotal; 
    int total;
    String metodoPago;
    String direccionEnvio;
    int cantkm;
    String producto;
    int cantProductos;
        public ServicioExpress(){
            this.nombrecliente="";
            this.numFactura=0;
            this.costoEnvio=0;
            this.total=0;
            this.subtotal=0;
            this.metodoPago="";
            this.direccionEnvio="";
            this.cantkm=0;
            this.producto="";
            this.cantProductos=0;
            
        }

    public String getNombrecliente() {
        return nombrecliente;
    }

    public void setNombrecliente(String nombrecliente) {
        this.nombrecliente = nombrecliente;
    }

    public int getNumFactura() {
        return numFactura;
    }

    public void setNumFactura(int numFactura) {
        this.numFactura = numFactura;
    }

    public int getCostoEnvio() {
        return costoEnvio;
    }

    public void setCostoEnvio(int costoEnvio) {
        this.costoEnvio = costoEnvio;
    }

    public int getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(int subtotal) {
        this.subtotal = subtotal;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public String getMetodoPago() {
        return metodoPago;
    }

    public void setMetodoPago(String metodoPago) {
        this.metodoPago = metodoPago;
    }

    public String getDireccionEnvio() {
        return direccionEnvio;
    }

    public void setDireccionEnvio(String direccionEnvio) {
        this.direccionEnvio = direccionEnvio;
        
    }

    public int getCantkm() {
        return cantkm;
    }

    public void setCantkm(int cantkm) {
        this.cantkm = cantkm;
    }

    public String getProducto() {
        return producto;
    }

    public void setProducto(String producto) {
        this.producto = producto;
    }

    public int getCantProductos() {
        return cantProductos;
    }

    public void setCantProductos(int cantProductos) {
        this.cantProductos = cantProductos;
    }
    
}
