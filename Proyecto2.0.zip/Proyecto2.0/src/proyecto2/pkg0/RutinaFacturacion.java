package proyecto2.pkg0;
import javax.swing.JOptionPane;
public class RutinaFacturacion {
   private Facturacion productos[]=new Facturacion[1];  
   private String s="";
   private char seguir;
    public void crearFactura(){
       int x;
       for (x=0;x<productos.length;x++){
           Facturacion f=new Facturacion();
           
           f.setNombreCliente(JOptionPane.showInputDialog(null, "Digite el nombre del ciente"));
           f.setCantArticulos(Integer.parseInt(JOptionPane.showInputDialog(null,"Digite la cantidad de articulos a comprar")));
           f.setNumeroFactura(Integer.parseInt(JOptionPane.showInputDialog(null,"Digite el numero de factura")));
           f.setFecha(JOptionPane.showInputDialog(null,"Digite la fecha con el formato xx/xx/xxxx"));
           f.setSubtotal(Integer.parseInt(JOptionPane.showInputDialog(null,"Digite el precio del producto")));
           f.setImpuesto(Double.parseDouble(JOptionPane.showInputDialog(null,"Digite el impuesto para agregarle")));
           f.setArticulo(JOptionPane.showInputDialog(null,"Digite el nombre del producto"));
           f.setTotal(f.getSubtotal()*f.getCantArticulos());
           f.setTotaltotal(f.getTotal()*f.getImpuesto());
           f.setTotal2(f.getTotal()+f.getTotaltotal());
            
           productos[x]=f;
               
           
           
       }
       
  
    }
    public void impresion(){
       int x;
       s=" ";
       for (x=0;x<productos.length;x++){
           JOptionPane.showMessageDialog(null,"*****Ferreteria Don Jose*****\n\n" + "Ced. 589856413\n" + "Cartago, Costa Rica\n\n\n"
           + "Caja....01\n\n" + "Numero de orden...." + productos[x].getNumeroFactura() + "\n" + "Fecha...." + productos[x].getFecha() + "\n"
           + "Nombre del cliente...." + productos[x].getNombreCliente() + "\n" +"Cantidad de productos...." + productos[x].getCantArticulos()+ "\n"
           + "Precio del producto...." + productos[x].getSubtotal() + "\n" + "Impuesto de ventas...." + productos[x].getImpuesto() + "\n"
           + "Nombre del articulo...." + productos[x].getArticulo() + "\n" + "Total a cancelar...." + productos[x].getTotal2());
       } 
    }
    
}
