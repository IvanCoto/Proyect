package proyecto2.pkg0;
public class Pinturas {
    
    int IDProducto;
    String Color; //se puede cambiar a codigo del color
    int CantidadLitros; // Este reperesenta la cantidad de listros del mismo color 
    double Precio;
    
   
    public Pinturas (){
        this.IDProducto = 0;
        this.Color = " ";
        this.CantidadLitros = 0;
        this.Precio = 0.00;
    
    }

    public int getIDProducto() {
        return IDProducto;
    }

    public void setIDProducto(int IDProducto) {
        this.IDProducto = IDProducto;
    }

    public String getColor() {
        return Color;
    }

    public void setColor(String Color) {
        this.Color = Color;
    }

    public int getCantidadLitros() {
        return CantidadLitros;
    }

    public void setCantidadLitros(int CantidadLitros) {
        this.CantidadLitros = CantidadLitros;
    }

    public double getPrecio() {
        return Precio;
    }

    public void setPrecio(double Precio) {
        this.Precio = Precio;
    }
    
            
}
