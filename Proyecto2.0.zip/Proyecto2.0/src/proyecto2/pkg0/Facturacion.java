
package proyecto2.pkg0;

public class Facturacion {
    String nombreCliente;
    int numeroFactura;
    String fecha;
    int subtotal;
    int cantArticulos;
    double impuesto;
    String articulo;
    int total;
    double totaltotal;
    double total2;
    
    
    public Facturacion(){
        this.nombreCliente = " ";
        this.numeroFactura = 0;
        this.fecha = " ";
        this.subtotal = 0;
        this.cantArticulos = 0;
        this.impuesto = 0.00;
        this.articulo = " ";
        this.total = 0;
        this.totaltotal=0.00;      
        this.total2=0.00;
    }

    public double getTotal2() {
        return total2;
    }

    public void setTotal2(double total2) {
        this.total2 = total2;
    }

    public double getTotaltotal() {
        return totaltotal;
    }

    public void setTotaltotal(double totaltotal) {
        this.totaltotal = totaltotal;
    }

   

    public String getNombreCliente() {
        return nombreCliente;
    }

    public void setNombreCliente(String nombreCliente) {
        this.nombreCliente = nombreCliente;
    }

    public int getNumeroFactura() {
        return numeroFactura;
    }

    public void setNumeroFactura(int numeroFactura) {
        this.numeroFactura = numeroFactura;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public int getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(int subtotal) {
        this.subtotal = subtotal;
    }

    public int getCantArticulos() {
        return cantArticulos;
    }

    public void setCantArticulos(int cantArticulos) {
        this.cantArticulos = cantArticulos;
    }

    public double getImpuesto() {
        return impuesto;
    }

    public void setImpuesto(double impuesto) {
        this.impuesto = impuesto;
    }

    public String getArticulo() {
        return articulo;
    }

    public void setArticulo(String articulo) {
        this.articulo = articulo;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

              
}
