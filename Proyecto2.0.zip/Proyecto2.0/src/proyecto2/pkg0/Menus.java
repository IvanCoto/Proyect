package proyecto2.pkg0;
import javax.swing.JOptionPane;
public class Menus {
        Rutina r=new Rutina ();
        RutinaHerramientas h=new RutinaHerramientas();
        RutinaJard j=new RutinaJard();
        RutinaPinturas p=new RutinaPinturas();
        RutinaFacturacion f=new RutinaFacturacion();
        RutinaProveedor a=new RutinaProveedor();
        RutinaServicioExpress e=new RutinaServicioExpress();
        
 public void menuGeneral(){
      int opcion=0;
      while(opcion!=4){
          opcion=Integer.parseInt(JOptionPane.showInputDialog(null,
                  "***MENÚ PRINCIPAL***\n\n"
                          + "1.Mostrar menu de clientes\n"
                          + "2. Mostrar departamentos\n"
                          + "3.Ir a facturacion\n"
                          + "4.Mostar Proveedores\n"
                          + "5.Servicio Express\n"
                          + "6.Salir\n"
                          + "\n\nDigite su opción:"));
          switch(opcion){
              case 1:{
                  menuClientes();
                  break;
              }
              
              case 2:{
                  departamentos();
              }

              case 3:{
                  Facturacion();
                  break;
              }    
              case 4:{
                  Proveedores();
                  break;
              }    
              
              case 5:{
                  servicioExpress();
                  break;
              }    
              case 6:{
                  System.exit(0);
                  break;
              }
              
              default:{
                  JOptionPane.showMessageDialog(null,"Opción incorrecta,elije otra opcion!");
              }
          }
      }
   }
 public void menuClientes(){
     
      int opcion=0;
      while(opcion!=5){
          opcion=Integer.parseInt(JOptionPane.showInputDialog(null,
                  "***MENÚ PRINCIPAL***\n\n"
                          + "1.Llenar base de datos de clientes\n"
                          + "2.Mostrar base de datos\n"
                          + "3.Buscar clientes\n"
                          + "4.Modificar cliente\n"
                          + "5.Eliminar clientes\n"
                          + "6.Volver al menu general\n"
                          + "7.Salir\n"
                          + "\n\nDigite su opción:"));
          switch(opcion){
              case 1:{
                  r.llenarVector();
                  break;
              }
              case 2:{
                  r.mostrarVector();
                  break;
              }
              case 3:{
                  r.buscarClientes();
                  break;
              }
              case 4:{
                  r.modificar();
                  break;
              }
              case 5:{
                  r.eliminar();
              }
              case 6:{
                  menuGeneral();
                  break;
              }
              case 7:{
                  System.exit(0);
                  break;
              }
              default:{
                  JOptionPane.showMessageDialog(null,"Opción incorrecta!");
              }
          }
      }
   }
 public void departamentos(){
        int opcion=0;
      while(opcion!=5){
          opcion=Integer.parseInt(JOptionPane.showInputDialog(null,
                  "***MENÚ PRINCIPAL***\n\n"
                          + "1.Mostrar menu de jardineria\n"
                          + "2.Mostrar menu de pinturas\n"
                          + "3.Mostrar menu de herramientas\n"
                          + "4.Volver al menu general\n"
                          + "5.Salir\n"
                          + "\n\nDigite su opción:"));
          switch(opcion){
              case 1:{
                  MenuJardineria();
                  break;
              }
              case 2:{
                  MenuPinturas();
                  break;
              }
              case 3:{
                  menuHeramientas();
                  break;
              }
              case 4:{
                  menuGeneral();
                  break;
              }
              case 5:{
                  System.exit(0);
                  break;
              }
              default:{
                  JOptionPane.showMessageDialog(null,"Opción incorrecta,elije otra opcion!");
              }
          }
      }
   }
 
 public void MenuJardineria(){
     int opcion=0;
      while(opcion!=5){
          opcion=Integer.parseInt(JOptionPane.showInputDialog(null,
                  "***MENÚ PRINCIPAL***\n\n"
                          + "1.Llenar inventario de jardineria\n"
                          + "2.Mostrar inventario de jardineria\n"
                          + "3.Buscar un producto de jardineria\n"
                          + "4.Volver al menu de departamentos\n"
                          + "5.Salir\n"
                          + "\n\nDigite su opción:"));
          switch(opcion){
              case 1:{
                  j.ingresarProductos();
                  break;
              }
              case 2:{
                  j.mostrarProductos();
                  break;
              }
              case 3:{
                  j.buscarProducto();
                  break;
              }
              case 4:{
                  departamentos();
                  break;
              }
              case 5:{
                  System.exit(0);
                  break;
              }
              default:{
                  JOptionPane.showMessageDialog(null,"Opción incorrecta!");
              }
          }
      }
   }
 public void MenuPinturas(){
           int opcion=0;
      while(opcion!=5){
          opcion=Integer.parseInt(JOptionPane.showInputDialog(null,
                  "***MENÚ PRINCIPAL***\n\n"
                          + "1.Llenar inventario de pinturas\n"
                          + "2.Mostrar inventarop de pinturas\n"
                          + "3.Buscar colores\n"
                          + "4.Volver al menu de departamentos\n"
                          + "5.Salir\n"
                          + "\n\nDigite su opción:"));
          switch(opcion){
              case 1:{
                  p.completarDatos();
                  break;
              }
              case 2:{
                  p.mostrarPinturas();
                  break;
              }
              case 3:{
                  p.buscarColor();
                  break;
              }
              case 4:{
                  departamentos();
                  break;
              }
              case 5:{
                  System.exit(0);
                  break;
              }
              default:{
                  JOptionPane.showMessageDialog(null,"Opción incorrecta,elije otra opcion!");
              }
          }
      }
   }
 public void menuHeramientas(){
     int opcion=0;
      while(opcion!=5){
          opcion=Integer.parseInt(JOptionPane.showInputDialog(null,
                  "***MENÚ PRINCIPAL***\n\n"
                          + "1.Llenar inventario de herramientas\n"
                          + "2.Mostrar inventario de herramientas\n"
                          + "3.Buscar herramientas\n"
                          + "4.Volver al menu de departamentos\n"
                          + "5.Salir\n"
                          + "\n\nDigite su opción:"));
          switch(opcion){
              case 1:{
                  h.llenarInventario();
                  break;
              }
              case 2:{
                  h.mostrarHerramientas();
                  break;
              }
              case 3:{
                  h.buscarHerramientas();
                  break;
              }
              case 4:{
                  departamentos();
                  break;
              }
              case 5:{
                  System.exit(0);
                  break;
              
              }
              default:{
                  JOptionPane.showMessageDialog(null,"Opción incorrecta!");
              }
          }
      }
   }
  public void Facturacion(){
      int opcion=0;
      while(opcion!=4){
          opcion=Integer.parseInt(JOptionPane.showInputDialog(null,
                  "***MENÚ PRINCIPAL***\n\n"
                          + "1.Crear factura\n"
                          + "2.Imprimir factura\n"
                          + "3.Volver al menu general\n"
                          + "4.Salir\n"
                           
                          + "\n\nDigite su opción:"));
          switch(opcion){
              case 1:{
                  f.crearFactura();
                  break;
              }
              case 2:{
                  f.impresion();
                  break;
              }
              case 3:{
                  menuGeneral();
                  break;
              }
              case 4:{
                  System.exit(0);
                  break;
              }
              default:{
                  JOptionPane.showMessageDialog(null,"Opción incorrecta,elije otra opcion!");
              }
          }
      }
   }
  public void Proveedores(){
      int opcion=0;
      while(opcion!=4){
          opcion=Integer.parseInt(JOptionPane.showInputDialog(null,
                  "***MENÚ PRINCIPAL***\n\n"
                          + "1.Llenar datos\n"
                          + "2.Mostar proveedores\n"
                          + "3.Volver al menu general\n"
                          + "4.Salir\n"
                           
                          + "\n\nDigite su opción:"));
          switch(opcion){
              case 1:{
                  a.Datos();
                  break;
              }
              case 2:{
                  a.MostrarProveedores();
                  break;
              }
              case 3:{
                  menuGeneral();
                  break;
              }
              case 4:{
                  System.exit(0);
                  break;
              }
              default:{
                  JOptionPane.showMessageDialog(null,"Opción incorrecta,elije otra opcion!");
              }
          }
      }
   }
  public void servicioExpress(){
      int opcion=0;
      while(opcion!=4){
          opcion=Integer.parseInt(JOptionPane.showInputDialog(null,
                  "***MENÚ PRINCIPAL***\n\n"
                          + "1.Crear pedido\n"
                          + "2.Imprimir pedido\n"
                          + "3.Volver al menu general\n"
                          + "3.Salir\n"
                           
                          + "\n\nDigite su opción:"));
          switch(opcion){
              case 1:{
                  e.solicitarDatos();
                  break;
              }
              case 2:{
                  e.crearPedido();
                  break;
              }
              case 3:{
                  menuGeneral();
                  break;
              }
              case 4:{
                  System.exit(0);
                  break;
              }
              default:{
                  JOptionPane.showMessageDialog(null,"Opción incorrecta,elije otra opcion!");
              }
          }
      }
   }
  }
  
 
 
 
 
 
 

