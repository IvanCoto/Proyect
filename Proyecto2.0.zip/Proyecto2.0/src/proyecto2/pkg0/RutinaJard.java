package proyecto2.pkg0;
import javax.swing.JOptionPane;
public class RutinaJard {
   private Jardineria productos[]=new Jardineria[4];
   private String s="";
   
   
   
   public void ingresarProductos(){
       int x;
      for(x=0;x<productos.length;x++){
          Jardineria j=new Jardineria();
          j.setIDProducto(Integer.parseInt(JOptionPane.showInputDialog(null,"Digite el ID del producto")));
          j.setnombreProducto(JOptionPane.showInputDialog(null,"Digite el nombre del producto"));
          j.setPrecio(Double.parseDouble(JOptionPane.showInputDialog(null, "Digite el precio del producto")));
          j.setCantidad(Integer.parseInt(JOptionPane.showInputDialog(null, "Digite la cantidad total de este articulo")));
          
          productos[x]=j;
  
      }
       
   }
   public void mostrarProductos(){
       int x;
      s="";
      for(x=0;x<productos.length;x++){
          s=s+"ID del producto...."+productos[x].getIDProducto() + "\n" + "Nombre del producto...." +productos[x].getnombreProducto() + "\n" +
                  "Precio del producto...."+productos[x].getPrecio() + "\n" + "Cantidad del producto...."+productos[x].getCantidad() + "\n\n "; 
      }
      JOptionPane.showMessageDialog(null,"Nuestros productos disponibles son:\n\n" + s);
      
   }
   
   public void buscarProducto(){ 
       int x;
       String nombreProducto;
       nombreProducto=JOptionPane.showInputDialog(null,"Digite el codigo del producto a buscar");
       
       for(x=0;x<productos.length;x++){
           if (productos[x].getnombreProducto().equals(nombreProducto)){
               JOptionPane.showMessageDialog(null,"El producto que se encontró es:\n" + productos[x].getnombreProducto() + " " +
                       productos[x].getIDProducto() + " " + productos[x].getPrecio() + " " + productos[x].getCantidad());
               
               
           
       }
     }
 
   }
}
