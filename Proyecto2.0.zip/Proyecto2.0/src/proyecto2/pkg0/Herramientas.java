
package proyecto2.pkg0;
public class Herramientas {
    int IDProducto;
    String nombreProducto;
    int cantidadProductos;
    double precio;
    
    
    public Herramientas(){
        this.IDProducto = 0;
        this.nombreProducto = " ";
        this.cantidadProductos = 0;
        this.precio=0.00;
                
    }

    public int getIDProducto() {
        return IDProducto;
    }

    public void setIDProducto(int IDProducto) {
        this.IDProducto = IDProducto;
    }

    public String getNombreProducto() {
        return nombreProducto;
    }

    public void setNombreProducto(String nombreProducto) {
        this.nombreProducto = nombreProducto;
    }

    public int getCantidadProductos() {
        return cantidadProductos;
    }

    public void setCantidadProductos(int cantidadProductos) {
        this.cantidadProductos = cantidadProductos;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }
    
}
