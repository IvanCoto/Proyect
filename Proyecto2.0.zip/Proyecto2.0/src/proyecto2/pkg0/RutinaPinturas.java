package proyecto2.pkg0;
import javax.swing.JOptionPane;
public class RutinaPinturas {
    
   private Pinturas pintura[]=new Pinturas[4];
   private String s="";
 
   
   public void completarDatos(){
    int x;
      for(x=0;x<pintura.length;x++){
          Pinturas t=new Pinturas();
          
          t.setIDProducto(Integer.parseInt(JOptionPane.showInputDialog(null,"Digite el ID del producto")));
          t.setColor(JOptionPane.showInputDialog(null, "Digite el color de la pintura"));
          t.setCantidadLitros(Integer.parseInt(JOptionPane.showInputDialog(null,"Digite la cantidad de litros almacenada de la pintura")));
          t.setPrecio(Double.parseDouble(JOptionPane.showInputDialog(null,"Digite el precio por litro del producto")));
          
          pintura[x]=t;
          
      }
   }  
public void mostrarPinturas(){
      int x;
      s="";
      for(x=0;x<pintura.length;x++){
          s=s+"ID del producto...."+pintura[x].getIDProducto() + "\n" + "Color disponible...." +pintura[x].getColor() + "\n" + "Cantidad de litros almacenados...."
                  +pintura[x].getCantidadLitros() + "\n" + "Precio del producto...."+pintura[x].getPrecio() + "\n\n";
          
      }
      JOptionPane.showMessageDialog(null, "Nuestros colores disponibles serian:" + s);
      
}   

public void buscarColor(){
    int x;
    String colorPintura;
    colorPintura=JOptionPane.showInputDialog(null, "Digite el color que desea buscar");
    
    
    for(x=0;x<pintura.length;x++){
        if (pintura[x].getColor().equals(colorPintura)){
            JOptionPane.showMessageDialog(null, "El producto que se encontro es: \n" + pintura[x].getIDProducto() + " " + pintura[x].getColor()
            + " " + pintura[x].getCantidadLitros() + " " + pintura[x].getPrecio());
        }
    }
}
}
      
   

   

