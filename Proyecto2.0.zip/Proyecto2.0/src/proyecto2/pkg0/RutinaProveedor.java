
package proyecto2.pkg0;
import javax.swing.JOptionPane;
public class RutinaProveedor {
    
   private Proveedor proveedores[]=new Proveedor[1];
   private String s="";
   
   public void Datos(){
       int x;
       for (x=0;x<proveedores.length;x++){
           Proveedor a=new Proveedor();
           
               a.setCodigo(Integer.parseInt(JOptionPane.showInputDialog(null,"Digite el codigo del proveedor")));
               a.setNombre(JOptionPane.showInputDialog("Digite el nombre del proveedor"));
               a.setProducto(JOptionPane.showInputDialog(null, "Digite el producto que le provee"));
               a.setTelefono(Integer.parseInt(JOptionPane.showInputDialog(null, "Digite el numero telefonico del proveedor " + a.getNombre() + 
                       " codigo " + a.getCodigo())));
               a.setDireccion(JOptionPane.showInputDialog(null, "Digite la direccion del proveedor " + a.getNombre() + " codigo " + a.getCodigo()));
               a.setEmail(JOptionPane.showInputDialog(null,"Digite el email del proveedor " + a.getNombre() + " codigo " + a.getCodigo()));
               proveedores[x] = a;     
       }
   } 
   public void MostrarProveedores(){
       int x;
       s = "";
       for (x=0;x<proveedores.length;x++){
           s = s + proveedores[x].getCodigo()+ " " + proveedores[x].getNombre()+ " " + proveedores[x].getProducto()+ " " + proveedores[x].getTelefono()+ " " + proveedores[x].getDireccion()+ 
                   " " + proveedores[x].getEmail() + " \n\n";
            
       }
       JOptionPane.showInputDialog(null, "Estos son nuestros proveedores:\n" + s);
   }
}
