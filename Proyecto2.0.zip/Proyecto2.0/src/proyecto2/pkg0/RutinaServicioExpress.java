package proyecto2.pkg0;
import javax.swing.JOptionPane;
public class RutinaServicioExpress {
    private ServicioExpress datos[]=new ServicioExpress[1];
    private String s = "";
    public void solicitarDatos(){
        int x;
        for (x=0;x<datos.length;x++){
        ServicioExpress e=new ServicioExpress();   
        
        e.setNombrecliente(JOptionPane.showInputDialog(null, "Digite el nombre del cliente"));
        e.setNumFactura(Integer.parseInt(JOptionPane.showInputDialog(null,"Digite el numero de factura")));
        e.setMetodoPago(JOptionPane.showInputDialog(null, "Digite el metodo de pago"));
        e.setDireccionEnvio(JOptionPane.showInputDialog(null, "Digite la direccion del envio"));
        e.setCostoEnvio(Integer.parseInt(JOptionPane.showInputDialog(null,"Digite el precio del envio por kilometro")));
        e.setCantkm(Integer.parseInt(JOptionPane.showInputDialog(null,"Digite la cantidad de KM")));
        e.setSubtotal(Integer.parseInt(JOptionPane.showInputDialog(null,"Digite el precio de los productos")));
        e.setCantProductos(Integer.parseInt(JOptionPane.showInputDialog(null,"Digite la cantidad de productos")));
        e.setProducto(JOptionPane.showInputDialog(null, "Digite el producto que va a comprar"));
        
        datos[x]=e;
        }
     }
    public void crearPedido(){
        int x;
        s="";
        JOptionPane.showMessageDialog(null, "Factura:\n");
        for(x=0;x<datos.length;x++){
            JOptionPane.showMessageDialog(null, "Nombre del cliente:" + " " +datos[x].getNombrecliente() + "\n" + "Numero de factura:" + " " +datos[x].getNumFactura()+"\n"
            + "Metodo de pago:" +" "+ datos[x].getMetodoPago()+ "\n" + "Direccion del envio:" +" "+ datos[x].getDireccionEnvio()+"\n" + "Costo del envio" +" "+ datos[x].getCostoEnvio()
            +"\n"+ "Cantidad de KM" +" "+ datos[x].getCantkm() +"\n"+ "Costo de los articulos" +" "+ datos[x].getSubtotal()+"\n" + "Cantidad de articulos" + datos[x].getCantProductos()+"\n"
            + "Nombre del producto:" +" "+ datos[x].getProducto());
        }    
    }
}
