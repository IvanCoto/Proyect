package proyecto2.pkg0;

public class Jardineria {
    
    int IDProducto;
    int cantidad;
    double precio;
    int articulosTotales;
    String nombreProducto; 
    
    
    
    public Jardineria(){
        
        this.IDProducto = 0;
        this.cantidad = 0;
        this.precio = 0.00;
        this.articulosTotales = 0;
        this.nombreProducto = " ";
            
        
    }

    public int getIDProducto() {
        return IDProducto;
    }

    public void setIDProducto(int IDProducto) {
        this.IDProducto = IDProducto;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getArticulosTotales() {
        return articulosTotales;
    }

    public void setArticulosTotales(int articulosTotales) {
        this.articulosTotales = articulosTotales;
    }

    public String getnombreProducto() {
        return nombreProducto;
    }

    public void setnombreProducto(String descripcionProducto) {
        this.nombreProducto = descripcionProducto;
    }
    
  
    
}
