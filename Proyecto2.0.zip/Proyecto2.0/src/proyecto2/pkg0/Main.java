package proyecto2.pkg0;

public class Main {
    public static void main(String[] args) {
        Menus m=new Menus();
        m.menuGeneral(); 
    }

}    
    
    

