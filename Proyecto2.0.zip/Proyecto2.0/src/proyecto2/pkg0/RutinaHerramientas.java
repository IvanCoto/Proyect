package proyecto2.pkg0;
import javax.swing.JOptionPane;
public class RutinaHerramientas {
    
   private Herramientas herramienta[]=new Herramientas[4];
   private String s="";
    
   public void llenarInventario(){
       int x;
       for (x=0;x<herramienta.length;x++){
           Herramientas h=new Herramientas();
           h.setIDProducto(Integer.parseInt(JOptionPane.showInputDialog("Digite el Id del producto")));
           h.setNombreProducto(JOptionPane.showInputDialog("Digite el nombre del producto"));
           h.setCantidadProductos(Integer.parseInt(JOptionPane.showInputDialog("Digite la cantidad del producto")));
           h.setPrecio(Integer.parseInt(JOptionPane.showInputDialog("Digite el precio del producto")));
           
           herramienta[x]=h;
           
       }
   }
   public void mostrarHerramientas(){
       int x;
       s=" ";
       for (x=0;x<herramienta.length;x++){
           s=s+"ID del producto...."+herramienta[x].getIDProducto() + "\n" +"Nombre de la herramienta...."+ 
                   herramienta[x].getNombreProducto() + "\n" +"Cantidad de"+ herramienta[x].getNombreProducto()+" "+herramienta[x].getCantidadProductos() + 
                   "\n" +"Precio del producto...."+ herramienta[x].getPrecio() + "\n\n";
       }
       JOptionPane.showMessageDialog(null, "Nuestras herramientas disponibles son:" + s);
       
   }
   public void buscarHerramientas(){
       int x;
       String herramientas;
       herramientas = JOptionPane.showInputDialog(null, "Digite la herramienta que esta buscando"); 
       
       for(x=0;x<herramienta.length;x++){
           if (herramienta[x].getNombreProducto().equals(herramientas)){
               JOptionPane.showMessageDialog(null, "El producto que se logro encontrar es: \n" + herramienta[x].getIDProducto() + " " + 
                       herramienta[x].getNombreProducto() + " " + herramienta[x].getCantidadProductos() + " " + herramienta[x].getPrecio());
           }
       }
       
   }
}
