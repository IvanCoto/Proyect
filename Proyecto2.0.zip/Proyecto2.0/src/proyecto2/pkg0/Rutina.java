package proyecto2.pkg0;
import javax.swing.JOptionPane;
public class Rutina {
    int opcionMod;
   private Cliente datos[]=new Cliente[3];
   private String s="";
   
   public void llenarVector(){
      int x;
      for(x=0;x<datos.length;x++){
          Cliente c=new Cliente();
          
          c.setNombre(JOptionPane.showInputDialog(null,"Digite el nombre del cliente:"));
          c.setApellido1(JOptionPane.showInputDialog(null,"Digite el primer apellido del cliente:"));
          c.setApellido2(JOptionPane.showInputDialog(null,"Digite el segundo apellido del cliente:"));
          c.setCedula(Integer.parseInt(JOptionPane.showInputDialog(null,"Digite el numero de cedula del cliente")));
          c.setTelefono(Integer.parseInt(JOptionPane.showInputDialog(null,"Digite el numero de telefono del cliente")));
          c.setCorreo(JOptionPane.showInputDialog(null,"Digite el correo electronico del cliente:"));
          c.setLugarResidencia(JOptionPane.showInputDialog(null,"Digite la provincia del cliente:"));
          
           datos[x]=c;    
      }
      
   }
   

 public void mostrarVector(){
      int x;
      s="";
      for(x=0;x<datos.length;x++){
          JOptionPane.showMessageDialog(null, "Nombre del cliente:" + datos[x].getNombre() +" "+ datos[x].getApellido1() +" "+ datos[x].getApellido2() +"\n"+
                  "Numero de cedula:" + datos[x].getCedula() +"\n"+ "Numero de telefono:" +" "+ datos[x].getTelefono() + "\n" + "Correo electronico" + datos[x].getCorreo()
          + "\n" + "Lugar de residencia" +" "+ datos[x].getLugarResidencia());  
    }
 }
public void buscarClientes(){
    String busqueda;
    busqueda=JOptionPane.showInputDialog(null,"Digite la forma en que quiere buscar los clientes(Nombre, primer apellido, segundo apellido, provincia de residencia)");
    if (busqueda.equals("Nombre")){
    int x;
    String nombreCliente;
    nombreCliente=JOptionPane.showInputDialog(null, "Digite el nombre del cliente a buscar");
    for (x=0;x<datos.length;x++){
        
        if (datos[x].getNombre().equals(nombreCliente)){
            JOptionPane.showMessageDialog(null, "El cliente que se encontro es:\n"+"Nombre del cliente"+" "+ datos[x].getNombre() + " " + 
                    datos[x].getApellido1() + " " + datos[x].getApellido2() + "\n" + "Numero de cedula"+" " + datos[x].getCedula() + "\n"  
                    +"Numero de telefono" + " " +datos[x].getTelefono() + "\n" +"Correo electronico"+ "" + datos[x].getCorreo() + "\n"
                    +"Lugar de residencia"+" "+ datos[x].getLugarResidencia());
                    
          }  
        }
    }
    String apellido1;
    int x;
    if (busqueda.equals("primer apellido")){
         apellido1=JOptionPane.showInputDialog(null, "Digite el primer apellido del cliente a buscar");
         for (x=0;x<datos.length;x++){
             if (datos[x].getApellido1().equals(apellido1)){
            JOptionPane.showMessageDialog(null, "El cliente que se encontro es:\n"+"Nombre del cliente"+" "+ datos[x].getNombre() + " " + 
                    datos[x].getApellido1() + " " + datos[x].getApellido2() + "\n" + "Numero de cedula"+" " + datos[x].getCedula() + "\n"  
                    +"Numero de telefono" + " " +datos[x].getTelefono() + "\n" +"Correo electronico"+ "" + datos[x].getCorreo() + "\n"
                    +"Lugar de residencia"+" "+ datos[x].getLugarResidencia());
                    
          }  
       }
   }
   String apellido2;
   if (busqueda.equals("segundo apellido")){
         apellido2=JOptionPane.showInputDialog(null, "Digite el segundo apellido del cliente a buscar");
         for (x=0;x<datos.length;x++){
             if (datos[x].getApellido2().equals(apellido2)){
            JOptionPane.showMessageDialog(null, "El cliente que se encontro es:\n"+"Nombre del cliente"+" "+ datos[x].getNombre() + " " + 
                    datos[x].getApellido1() + " " + datos[x].getApellido2() + "\n" + "Numero de cedula"+" " + datos[x].getCedula() + "\n"  
                    +"Numero de telefono" + " " +datos[x].getTelefono() + "\n" +"Correo electronico"+ "" + datos[x].getCorreo() + "\n"
                    +"Lugar de residencia"+" "+ datos[x].getLugarResidencia());
                    
          }  
       }
   }
   String residencia;
      if (busqueda.equals("provincia de residencia")){
         residencia=JOptionPane.showInputDialog(null, "Digite la provincia de residencia del cliente a buscar");
         for (x=0;x<datos.length;x++){
             if (datos[x].getLugarResidencia().equals(residencia)){
            JOptionPane.showMessageDialog(null, "El cliente que se encontro es:\n"+"Nombre del cliente"+" "+ datos[x].getNombre() + " " + 
                    datos[x].getApellido1() + " " + datos[x].getApellido2() + "\n" + "Numero de cedula"+" " + datos[x].getCedula() + "\n"  
                    +"Numero de telefono" + " " +datos[x].getTelefono() + "\n" +"Correo electronico"+ "" + datos[x].getCorreo() + "\n"
                    +"Lugar de residencia"+" "+ datos[x].getLugarResidencia());
                    
          }  
       }
   }
}
public void modificar(){
    int x;
    String nombreCliente1;
    nombreCliente1=JOptionPane.showInputDialog(null,"Digite el nombre del cliente a buscar para modificar");
        for (x=0;x<datos.length;x++){
        Cliente c=new Cliente();
        
        if (datos[x].getNombre().equals(nombreCliente1)){
            JOptionPane.showMessageDialog(null, "El cliente que se encontro para modificar es:\n"+"Nombre del cliente"+" "+ datos[x].getNombre() + " " + 
                    datos[x].getApellido1() + " " + datos[x].getApellido2() + "\n" + "Numero de cedula"+" " + datos[x].getCedula() + "\n"  
                    +"Numero de telefono" + " " +datos[x].getTelefono() + "\n" +"Correo electronico"+ "" + datos[x].getCorreo() + "\n"
                    +"Lugar de residencia"+" "+ datos[x].getLugarResidencia());
                    
          c.setNombre(JOptionPane.showInputDialog(null,"Digite el nombre del cliente:"));
          c.setApellido1(JOptionPane.showInputDialog(null,"Digite el primer apellido del cliente:"));
          c.setApellido2(JOptionPane.showInputDialog(null,"Digite el segundo apellido del cliente:"));
          c.setCedula(Integer.parseInt(JOptionPane.showInputDialog(null,"Digite el numero de cedula del cliente")));
          c.setTelefono(Integer.parseInt(JOptionPane.showInputDialog(null,"Digite el numero de telefono del cliente")));
          c.setCorreo(JOptionPane.showInputDialog(null,"Digite el correo electronico del cliente:"));
          c.setLugarResidencia(JOptionPane.showInputDialog(null,"Digite la provincia del cliente:"));
          
           datos[x]=c;  
          }  
        }
    
}
public void eliminar(){
    int x;
    String nombreCliente1;
    String opcion;
    nombreCliente1=JOptionPane.showInputDialog(null,"Digite el nombre del cliente a buscar para modificar");
        for (x=0;x<datos.length;x++){
        Cliente c=new Cliente();
        
        if (datos[x].getNombre().equals(nombreCliente1)){
            JOptionPane.showMessageDialog(null, "El cliente que se encontro para modificar es:\n"+"Nombre del cliente"+" "+ datos[x].getNombre() + " " + 
                    datos[x].getApellido1() + " " + datos[x].getApellido2() + "\n" + "Numero de cedula"+" " + datos[x].getCedula() + "\n"  
                    +"Numero de telefono" + " " +datos[x].getTelefono() + "\n" +"Correo electronico"+ "" + datos[x].getCorreo() + "\n"
                    +"Lugar de residencia"+" "+ datos[x].getLugarResidencia());
            opcion=JOptionPane.showInputDialog(null,"¿Desea eliminarlo?");
            if (opcion.equals("si")){
                JOptionPane.showMessageDialog(null, "Usuario elminado");
                c.setNombre("");
                c.setApellido1("");
                c.setApellido2("");
                c.setCedula(0);
                c.setTelefono(0);
                c.setCorreo("");
                c.setLugarResidencia("");
                
                datos[x]=c;
            }
            
        }  
   }         
 }
}


